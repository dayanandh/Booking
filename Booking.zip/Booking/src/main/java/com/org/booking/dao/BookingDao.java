package com.org.booking.dao;

import java.math.BigDecimal;

import org.springframework.data.repository.CrudRepository;

import com.org.booking.model.Booking;


public interface BookingDao extends CrudRepository<Booking, BigDecimal> {

}
