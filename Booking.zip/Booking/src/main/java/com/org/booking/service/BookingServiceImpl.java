package com.org.booking.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.org.booking.dao.BookingDao;
import com.org.booking.exception.RecordNotFoundException;
import com.org.booking.model.Booking;
@Service
public class BookingServiceImpl implements BookingService {

	@Autowired
	BookingDao bookingDao;
	
	@Override
	public Booking getBookingDetails(BigDecimal id) {
		Optional<Booking> bookingDetails = bookingDao.findById(id);
		return bookingDetails.get();
	}

	@Override
	public Booking save(Booking bokingDetails) {
		Booking boolingDetails = bookingDao.save(bokingDetails);
		return boolingDetails;
	}

	@Override
	public Iterable<Booking> displayAllBooking() {
		return bookingDao.findAll();
	}

	@Override
	public ResponseEntity<String> updateBooking(Booking updateBooking) {
		Optional<Booking> findBookingById = bookingDao.findById(updateBooking.getBookingId());
		if (findBookingById.isPresent()) {
			bookingDao.save(updateBooking);
			return new ResponseEntity<String>("Booking Update completed", HttpStatus.OK);
		} else {
			throw new RecordNotFoundException(
					"Booking with Booking Id: " + updateBooking.getBookingId() + " not exists!!");
		}
		
	}

	@Override
	public ResponseEntity<String> deleteBooking(BigDecimal bookingId) {
		Optional<Booking> findBookingById = bookingDao.findById(bookingId);
		if (findBookingById.isPresent()) {
			bookingDao.deleteById(bookingId);
			return new ResponseEntity<String>("Booking Deleted", HttpStatus.OK);
		} else
			throw new RecordNotFoundException("Booking not found for the entered BookingID");		
	}

}
