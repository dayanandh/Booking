package com.org.booking.service;

import java.math.BigDecimal;
import java.math.BigInteger;

import org.springframework.http.ResponseEntity;

import com.org.booking.model.Booking;

public interface BookingService {
	
	public Booking getBookingDetails(BigDecimal id);
	
	public Booking save(Booking bokingDetails);

	public Iterable<Booking> displayAllBooking();

	public ResponseEntity<String> updateBooking(Booking updateBooking);

	public ResponseEntity<String> deleteBooking(BigDecimal bookingId);


}
