package com.org.booking.controller;

import java.math.BigDecimal;
import java.math.BigInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.org.booking.exception.RecordNotFoundException;
import com.org.booking.model.Booking;
import com.org.booking.service.BookingService;
@RestController
@RequestMapping("/Booking")
public class BookingController {
	
	@Autowired
	BookingService bookingService;
	
	@GetMapping("/getDetails/{id}")
	public Booking getBookingDetails(@PathVariable("id") BigDecimal id) {
		return bookingService.getBookingDetails(id);
	}
	
	@PostMapping("/createBooking")
	public Booking saveBookingDetails(@RequestBody Booking details) {
		return bookingService.save(details);
	}
	
	@GetMapping("/readAllBooking")
	public Iterable<Booking> readAllBookings() {

		return bookingService.displayAllBooking();
	}

	@PutMapping("/updateBooking")
	@ExceptionHandler(RecordNotFoundException.class)
	public ResponseEntity<String> modifyBooking(@RequestBody Booking updateBooking) {

		return bookingService.updateBooking(updateBooking);
	}

	
	@DeleteMapping("/deleteBooking/{id}")
	@ExceptionHandler(RecordNotFoundException.class)
	public ResponseEntity<String> deleteBookingByID(@PathVariable("id") BigDecimal bookingId) {

		return bookingService.deleteBooking(bookingId);
	}
	
}


